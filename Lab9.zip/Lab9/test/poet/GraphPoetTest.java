package poet;

import static org.junit.Assert.*;

import org.junit.Test;
import java.io.File;
import java.io.IOException;

/**
 * Tests for GraphPoet.
 */
public class GraphPoetTest {

    @Test(expected = AssertionError.class)
    public void testAssertionsEnabled() {
        assert false; // Ensure assertions are enabled with JVM argument: -ea
    }

    @Test
    public void testGraphPoetFileDoesNotExist() {
        try {
            new GraphPoet(new File("nonexistent.txt"));
            fail("Expected IOException was not thrown");
        } catch (IOException e) {
            assertTrue(e.getMessage().contains("nonexistent.txt"));
        }
    }

    @Test
    public void testGraphPoetEmptyFile() throws IOException {
        GraphPoet poet = new GraphPoet(new File("src/poet/empty.txt"));
        assertEquals("This is a test.", poet.poem("This is a test."));
    }

    @Test
    public void testGraphPoetFileWithOneWord() throws IOException {
        GraphPoet poet = new GraphPoet(new File("src/poet/oneWord.txt"));
        assertEquals("This is a test.", poet.poem("This is a test."));
    }

    @Test
    public void testGraphPoetFileWithMultipleWords() throws IOException {
        GraphPoet poet = new GraphPoet(new File("src/poet/mugar-omni-theater.txt"));
        assertEquals("Test of the system.", poet.poem("Test the system."));
        assertEquals("", poet.poem(""));
        assertEquals("Test.", poet.poem("Test."));
    }

    @Test
    public void testGraphPoetGraphWithCycles() throws IOException {
        GraphPoet poet = new GraphPoet(new File("src/poet/test.txt"));
        assertEquals("This is worth a test.", poet.poem("This is a test."));
    }
}
