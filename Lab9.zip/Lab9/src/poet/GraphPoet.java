package poet;

import graph.ConcreteEdgesGraph;
import graph.Graph;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;
import java.util.Map;

/**
 * A graph-based poetry generator.
 */
public class GraphPoet {

    private final Graph<String> graph;

    // Abstraction function:
    //   Represents a word affinity graph where:
    //   - Vertices are unique lowercase words from the corpus.
    //   - Edges represent adjacency with weights equal to the frequency of occurrences.
    //
    // Representation invariant:
    //   - All vertices are lowercase, non-empty strings.
    //   - All edge weights are positive.
    //
    // Safety from rep exposure:
    //   - The graph is private and final.
    //   - Internal state is not exposed to the client.

    /**
     * Create a new poet using a word affinity graph derived from the corpus.
     *
     * @param corpus text file from which to derive the affinity graph
     * @throws IOException if the corpus file cannot be found or read
     */
    public GraphPoet(File corpus) throws IOException {
        this.graph = new ConcreteEdgesGraph<>();

        // Read all lines from the file and split into words
        List<String> words = Files.lines(corpus.toPath())
                .flatMap(line -> List.of(line.split("\\s+")).stream())
                .map(String::toLowerCase)
                .filter(word -> !word.isEmpty())
                .toList();

        // Build the graph by adding vertices and edges
        for (int i = 0; i < words.size() - 1; i++) {
            String source = words.get(i);
            String target = words.get(i + 1);

            int currentWeight = graph.targets(source).getOrDefault(target, 0);
            graph.set(source, target, currentWeight + 1);
        }

        checkRep();
    }

    /**
     * Ensure the representation invariant is upheld.
     */
    private void checkRep() {
        for (String vertex : graph.vertices()) {
            assert !vertex.isEmpty() : "Vertex cannot be empty";
            assert vertex.equals(vertex.toLowerCase()) : "Vertex must be lowercase";
            for (Map.Entry<String, Integer> edge : graph.targets(vertex).entrySet()) {
                assert edge.getValue() > 0 : "Edge weight must be positive";
            }
        }
    }

    /**
     * Generate a poem from the input string by inserting bridge words.
     *
     * @param input string from which to create the poem
     * @return a poem with bridge words inserted
     */
    public String poem(String input) {
        String[] words = input.split("\\s+");
        StringBuilder poem = new StringBuilder();

        for (int i = 0; i < words.length - 1; i++) {
            String source = words[i].toLowerCase();
            String target = words[i + 1].toLowerCase();

            // Find the bridge word with the maximum weight
            String bestBridge = null;
            int maxWeight = 0;

            for (Map.Entry<String, Integer> entry : graph.targets(source).entrySet()) {
                String bridge = entry.getKey();
                int sourceToBridge = entry.getValue();
                int bridgeToTarget = graph.targets(bridge).getOrDefault(target, 0);

                int combinedWeight = sourceToBridge + bridgeToTarget;
                if (bridgeToTarget > 0 && combinedWeight > maxWeight) {
                    bestBridge = bridge;
                    maxWeight = combinedWeight;
                }
            }

            // Append the source word and the bridge word (if found)
            poem.append(words[i]).append(" ");
            if (bestBridge != null) {
                poem.append(bestBridge).append(" ");
            }
        }

        // Append the last word
        poem.append(words[words.length - 1]);
        return poem.toString().trim();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("GraphPoet Affinity Graph:\n");
        for (String vertex : graph.vertices()) {
            sb.append(vertex).append(" -> ").append(graph.targets(vertex)).append("\n");
        }
        return sb.toString();
    }
}
